# Define your database connection parameters
username = 'CBS_APPS'
password = 'CBS_APPS'
host = '172.168.101.238'
port = '1521'
service_name = 'PDB1'