j = 10  # Replace "Your Name" with your actual name

for i in range(10):
    print(i+j)

class Jeeth:

    def my_1st_method(self):
        print("1st methond")
    def my_2nd_method(self):
        print('Jeeth- 2nd method')

obj=Jeeth()
obj.my_1st_method()
obj.my_2nd_method()