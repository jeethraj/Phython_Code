# Define your database connection parameters
username = 'CBS_APPS'
password = 'CBS_APPS'
host = '172.168.101.103'
port = '1521'
service_name = 'ZSSUAT'

#Define EIA connection details
eia_username="tecnotree"
eia_password="tecnotree#789"
eia_url = "https://zainbss-uat.ss.zain.com/services/EIAproxy"